a:=4;
b:=7;
res:=1;
for x:=1 step 1 until 3 do
    res:=res*a
endloop;