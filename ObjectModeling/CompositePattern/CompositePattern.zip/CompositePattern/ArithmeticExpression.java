package CompositePattern;

public abstract class ArithmeticExpression {

    public abstract void add(ArithmeticExpression value);
    public abstract int evaluate();

}
