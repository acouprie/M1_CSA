package CompositePattern.Tests;

public class Test1 {
}
