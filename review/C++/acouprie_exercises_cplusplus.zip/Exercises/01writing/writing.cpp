#include <iostream>
using namespace std;

int main() {
    int age = 14;
    cout << "You are " << age <<" years old.\nYou are too young to play this game.\n";
    return 0;
}